# flag-while
flag controlled while loop
